import Vue from 'vue'
import Vuex from 'vuex'
// import * as getters from './getters.js'

Vue.use(Vuex)

/** 状态定义 */
export const state = {
  money_id:localStorage.getItem('money_id')==undefined?0:parseInt(localStorage.getItem('money_id')),//推广金额存储
  region:localStorage.getItem('region')==undefined?0:parseInt(localStorage.getItem('region')),//案例类型
  // host:"http://www.markets.com/index.php/port",
  // host:"http://flow.xingyuanauto.com/FlowProject/MarketingTest/public/index.php/port/",//测试
  host:"https://water.xingyuanauto.com/port/",//上线

  // host:"http://"+window.location.host+"/port/"//接口路径
}

export default new Vuex.Store({
    state,
})
